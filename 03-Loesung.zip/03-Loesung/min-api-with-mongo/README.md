# Minimal Api with MongoDB
Musterlösung für Arbeitsauftrag 4